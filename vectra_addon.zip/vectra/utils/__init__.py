"""Utility helpers for Vectra."""
